package com.example.recyclerview

data class DataClass(var itemName: String, var itemDetail: String)
